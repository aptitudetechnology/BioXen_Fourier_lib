# Test configuration and utilities
