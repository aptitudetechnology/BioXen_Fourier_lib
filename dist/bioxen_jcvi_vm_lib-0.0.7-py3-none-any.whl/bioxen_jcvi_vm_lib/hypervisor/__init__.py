# Hypervisor core module
