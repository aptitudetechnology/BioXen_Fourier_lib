"""Test suite for BioXen Factory Pattern API"""
